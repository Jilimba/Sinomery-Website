# Project Sinomery – Password / Landing Page

Single-page landing site: full-width looping video, blackletter logo, "I know the password" overlay and an email sign-up form.

## Structure

```
index.html            page (HTML + CSS + JS in one file)
assets/
  sinomery-ad.mp4     looping background ad (720p, muted)
  poster.jpg          still shown while the video loads
.nojekyll             tells GitHub Pages to serve files as-is
```

## Run locally

Open `index.html` in a browser, or run `python3 -m http.server` in this folder and visit http://localhost:8000.

## Deploy with GitHub Pages

1. Push to your branch.
2. Repo → Settings → Pages → choose that branch, folder `/ (root)`, Save.
3. Site goes live at `https://<username>.github.io/<repo>/`.

## To do

- Connect the sign-up form to a real email list (Mailchimp, Klaviyo, etc.). It currently only validates the email.
- Set the real password check (it currently always shows "Incorrect password").
- Replace the text logo with the final logo file.
